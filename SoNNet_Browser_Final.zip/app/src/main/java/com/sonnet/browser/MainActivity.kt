package com.sonnet.browser
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val runtime = GeckoRuntime.create(this)
        val session = GeckoSession()
        session.open(runtime)
        session.loadUri("https://browserleaks.com/ip")
        setContent {
            AndroidView(
                factory = { context -> GeckoView(context).apply { setSession(session) } },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}