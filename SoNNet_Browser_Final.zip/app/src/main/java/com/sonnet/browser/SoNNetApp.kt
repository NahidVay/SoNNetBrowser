package com.sonnet.browser
import android.app.Application
class SoNNetApp : Application()