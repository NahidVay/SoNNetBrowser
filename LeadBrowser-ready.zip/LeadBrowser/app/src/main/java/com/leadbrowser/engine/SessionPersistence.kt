package com.leadbrowser.engine

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionPersistence @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "lead_browser_sessions",
        Context.MODE_PRIVATE
    )
    private val gson = Gson()

    data class SavedSession(
        val sessionId: String,
        val profileJson: String,
        val proxyId: Long?,
        val lastUrl: String?,
        val timestamp: Long = System.currentTimeMillis()
    )

    fun saveSession(session: SavedSession) {
        prefs.edit()
            .putString("session_${session.sessionId}", gson.toJson(session))
            .putLong("session_time_${session.sessionId}", session.timestamp)
            .apply()
    }

    fun restoreAllSessions(): List<SavedSession> {
        val sessions = mutableListOf<SavedSession>()
        val allKeys = prefs.all.keys.filter {
            it.startsWith("session_") && !it.startsWith("session_time_")
        }

        allKeys.forEach { key ->
            try {
                val json = prefs.getString(key, null)
                if (json != null) {
                    sessions.add(gson.fromJson(json, SavedSession::class.java))
                }
            } catch (e: Exception) {
                // Ignore corrupt sessions
            }
        }

        return sessions.sortedByDescending { it.timestamp }
    }

    fun cleanupOldSessions() {
        val sevenDaysAgo = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000)
        val editor = prefs.edit()

        prefs.all.keys.filter { it.startsWith("session_time_") }.forEach { key ->
            val timestamp = prefs.getLong(key, 0)
            if (timestamp < sevenDaysAgo) {
                val sessionId = key.removePrefix("session_time_")
                editor.remove("session_$sessionId")
                editor.remove(key)
            }
        }

        editor.apply()
    }

    fun removeSession(sessionId: String) {
        prefs.edit()
            .remove("session_$sessionId")
            .remove("session_time_$sessionId")
            .apply()
    }

    fun getLastUrl(sessionId: String): String? {
        val json = prefs.getString("session_$sessionId", null) ?: return null
        return try {
            gson.fromJson(json, SavedSession::class.java).lastUrl
        } catch (e: Exception) {
            null
        }
    }
}