package com.leadbrowser.engine.proxy

import com.leadbrowser.data.local.ProxyConfig
import com.leadbrowser.data.local.ProxyDao
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProxyManager @Inject constructor(
    private val proxyDao: ProxyDao,
    private val localProxyServer: LocalProxyServer
) {

    private val _currentProxy = MutableStateFlow<ProxyConfig?>(null)
    val currentProxy: StateFlow<ProxyConfig?> = _currentProxy

    suspend fun getNextProxy(): ProxyConfig? {
        val proxy = proxyDao.getNextProxy()
        if (proxy != null) {
            proxyDao.updateLastUsed(proxy.id, System.currentTimeMillis())
            _currentProxy.value = proxy
            localProxyServer.setCurrentProxy(proxy)
        }
        return proxy
    }

    fun getCurrentProxy(): ProxyConfig? {
        return _currentProxy.value
    }

    fun setProxy(proxy: ProxyConfig) {
        _currentProxy.value = proxy
        localProxyServer.setCurrentProxy(proxy)
    }
}