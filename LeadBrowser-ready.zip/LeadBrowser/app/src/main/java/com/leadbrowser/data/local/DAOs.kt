package com.leadbrowser.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProxyDao {

    @Query("SELECT * FROM proxies WHERE isActive = 1 ORDER BY lastUsed ASC")
    fun getAllActiveProxies(): Flow<List<ProxyConfig>>

    @Query("SELECT * FROM proxies WHERE isActive = 1 ORDER BY lastUsed ASC LIMIT 1")
    suspend fun getNextProxy(): ProxyConfig?

    @Query("SELECT * FROM proxies WHERE id = :proxyId")
    suspend fun getProxyById(proxyId: Long): ProxyConfig?

    @Query("SELECT COUNT(*) FROM proxies WHERE isActive = 1")
    suspend fun getActiveProxyCount(): Int

    @Query("UPDATE proxies SET lastUsed = :timestamp WHERE id = :id")
    suspend fun updateLastUsed(id: Long, timestamp: Long)

    @Query("UPDATE proxies SET isActive = 0 WHERE id = :id")
    suspend fun deactivateProxy(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(proxy: ProxyConfig)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(proxies: List<ProxyConfig>)

    @Update
    suspend fun update(proxy: ProxyConfig)

    @Delete
    suspend fun delete(proxy: ProxyConfig)

    @Query("DELETE FROM proxies WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM proxies")
    suspend fun deleteAll()
}

@Dao
interface ApiConfigDao {

    @Query("SELECT * FROM api_configs WHERE isActive = 1")
    fun getActiveConfigs(): Flow<List<ApiConfig>>

    @Query("SELECT * FROM api_configs")
    fun getAllConfigs(): Flow<List<ApiConfig>>

    @Query("SELECT * FROM api_configs WHERE id = :id")
    suspend fun getConfigById(id: Long): ApiConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(config: ApiConfig)

    @Update
    suspend fun update(config: ApiConfig)

    @Delete
    suspend fun delete(config: ApiConfig)

    @Query("DELETE FROM api_configs WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE api_configs SET lastFetched = :timestamp WHERE id = :id")
    suspend fun updateLastFetched(id: Long, timestamp: Long)

    @Query("UPDATE api_configs SET isActive = :isActive WHERE id = :id")
    suspend fun updateActiveStatus(id: Long, isActive: Boolean)
}

@Dao
interface DeviceDao {

    @Query("SELECT * FROM custom_devices ORDER BY createdAt DESC")
    fun getCustomDevices(): Flow<List<CustomDeviceProfile>>

    @Query("SELECT * FROM custom_devices WHERE id = :id")
    suspend fun getDeviceById(id: Long): CustomDeviceProfile?

    @Query("SELECT COUNT(*) FROM custom_devices")
    suspend fun getDeviceCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(device: CustomDeviceProfile)

    @Update
    suspend fun update(device: CustomDeviceProfile)

    @Delete
    suspend fun delete(device: CustomDeviceProfile)

    @Query("DELETE FROM custom_devices WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface VisitHistoryDao {

    @Query("SELECT * FROM visit_history ORDER BY timestamp DESC LIMIT 100")
    fun getRecentVisits(): Flow<List<VisitHistory>>

    @Query("SELECT * FROM visit_history WHERE sessionId = :sessionId ORDER BY timestamp DESC")
    fun getVisitsBySession(sessionId: String): Flow<List<VisitHistory>>

    @Insert
    suspend fun insert(visit: VisitHistory)

    @Query("DELETE FROM visit_history WHERE timestamp < :beforeTimestamp")
    suspend fun deleteOlderThan(beforeTimestamp: Long)

    @Query("DELETE FROM visit_history")
    suspend fun deleteAll()
}