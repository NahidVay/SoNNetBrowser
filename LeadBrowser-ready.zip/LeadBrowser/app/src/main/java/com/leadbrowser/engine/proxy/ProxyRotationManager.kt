package com.leadbrowser.engine.proxy

import com.leadbrowser.data.local.ApiConfig
import com.leadbrowser.data.local.ApiConfigDao
import com.leadbrowser.data.local.ProxyDao
import com.leadbrowser.data.remote.ProxyApiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProxyRotationManager @Inject constructor(
    private val apiConfigDao: ApiConfigDao,
    private val proxyDao: ProxyDao,
    private val apiService: ProxyApiService
) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val jobs = mutableMapOf<Long, Job>()

    fun startAutoRotation(config: ApiConfig) {
        jobs[config.id]?.cancel()
        jobs[config.id] = scope.launch {
            while (isActive) {
                fetchAndUpdate(config)
                delay(config.refreshInterval)
            }
        }
    }

    fun stopAutoRotation(id: Long) {
        jobs[id]?.cancel()
        jobs.remove(id)
    }

    private suspend fun fetchAndUpdate(config: ApiConfig) {
        val list = apiService.fetchProxiesFromApi(config)
        if (list.isNotEmpty()) {
            list.forEach { proxyDao.insert(it) }
            apiConfigDao.updateLastFetched(config.id, System.currentTimeMillis())
        }
    }

    fun stopAll() {
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        scope.cancel()
    }
}