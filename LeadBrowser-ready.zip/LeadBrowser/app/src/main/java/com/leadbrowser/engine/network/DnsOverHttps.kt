package com.leadbrowser.engine.network

import org.mozilla.geckoview.GeckoRuntime

class DnsOverHttps {

    fun configureDns(runtime: GeckoRuntime) {
        val settings = runtime.settings
        settings.setBoolean("network.trr.mode", true)
        settings.setString("network.trr.uri", "https://cloudflare-dns.com/dns-query")
        settings.setBoolean("network.dns.disableIPv6", true)
        settings.setBoolean("network.prefetch-next", false)
        settings.setBoolean("network.dns.disablePrefetch", true)
    }
}