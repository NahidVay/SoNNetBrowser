package com.leadbrowser.engine.proxy

import com.leadbrowser.data.local.ProxyConfig
import com.leadbrowser.data.local.ProxyDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProxyHealthChecker @Inject constructor(
    private val proxyDao: ProxyDao
) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _healthStatus = MutableStateFlow<Map<Long, ProxyHealth>>(emptyMap())
    val healthStatus: StateFlow<Map<Long, ProxyHealth>> = _healthStatus

    data class ProxyHealth(
        val proxyId: Long,
        val isAlive: Boolean,
        val latencyMs: Long = 0,
        val speedKbps: Double = 0.0,
        val lastChecked: Long = System.currentTimeMillis(),
        val errorMessage: String? = null
    )

    fun checkAllProxies() {
        scope.launch {
            proxyDao.getAllActiveProxies().collect { proxies ->
                proxies.forEach { proxy ->
                    launch {
                        val health = testProxy(proxy)
                        _healthStatus.value = _healthStatus.value + (proxy.id to health)
                    }
                }
            }
        }
    }

    suspend fun testProxy(proxy: ProxyConfig): ProxyHealth = withContext(Dispatchers.IO) {
        try {
            val proxyAddress = InetSocketAddress(proxy.host, proxy.port)
            val javaProxy = Proxy(Proxy.Type.SOCKS, proxyAddress)

            val clientBuilder = OkHttpClient.Builder()
                .proxy(javaProxy)
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)

            if (proxy.username != null && proxy.password != null) {
                clientBuilder.proxyAuthenticator { _, response ->
                    val credential = Credentials.basic(proxy.username, proxy.password)
                    response.request.newBuilder()
                        .header("Proxy-Authorization", credential)
                        .build()
                }
            }

            val client = clientBuilder.build()

            val testStart = System.currentTimeMillis()
            val request = Request.Builder()
                .url("https://api.ipify.org?format=json")
                .build()

            val response = client.newCall(request).execute()
            val latency = System.currentTimeMillis() - testStart

            if (response.isSuccessful) {
                val bodySize = response.body?.contentLength() ?: 0L
                val speed = if (latency > 0) (bodySize.toDouble() / latency) else 0.0

                ProxyHealth(
                    proxyId = proxy.id,
                    isAlive = true,
                    latencyMs = latency,
                    speedKbps = speed
                )
            } else {
                ProxyHealth(
                    proxyId = proxy.id,
                    isAlive = false,
                    errorMessage = "HTTP ${response.code}"
                )
            }
        } catch (e: Exception) {
            ProxyHealth(
                proxyId = proxy.id,
                isAlive = false,
                errorMessage = e.message ?: "Connection failed"
            )
        }
    }

    fun getAliveProxies(): List<ProxyHealth> {
        return _healthStatus.value.values.filter { it.isAlive }
    }
}