package com.leadbrowser.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "proxies")
data class ProxyConfig(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val host: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val type: String = "SOCKS5",
    val country: String? = null,
    val city: String? = null,
    val geoLat: Double = 0.0,
    val geoLon: Double = 0.0,
    val geoTimezone: String = "America/New_York",
    val isResidential: Boolean = true,
    val lastUsed: Long = 0,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "api_configs")
data class ApiConfig(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val endpoint: String,
    val apiKey: String? = null,
    val refreshInterval: Long = 300000,
    val isActive: Boolean = true,
    val lastFetched: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_devices")
data class CustomDeviceProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val model: String,
    val screenWidth: Int,
    val screenHeight: Int,
    val dpr: Float,
    val cpuCores: Int,
    val ram: Int,
    val gpuVendor: String,
    val gpuRenderer: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "visit_history")
data class VisitHistory(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val url: String,
    val proxyId: Long?,
    val sessionId: String,
    val deviceModel: String,
    val timestamp: Long = System.currentTimeMillis(),
    val success: Boolean = true
)