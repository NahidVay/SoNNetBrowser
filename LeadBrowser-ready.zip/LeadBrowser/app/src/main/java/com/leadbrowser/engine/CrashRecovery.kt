package com.leadbrowser.engine

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CrashRecovery @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "crash_recovery",
        Context.MODE_PRIVATE
    )
    private val gson = Gson()

    data class TabState(
        val sessionId: String,
        val url: String,
        val title: String,
        val profileId: String,
        val proxyId: Long?
    )

    fun saveTabs(tabs: List<TabState>) {
        prefs.edit()
            .putString("tabs", gson.toJson(tabs))
            .putLong("saved_at", System.currentTimeMillis())
            .apply()
    }

    fun restoreTabs(): List<TabState> {
        val json = prefs.getString("tabs", null) ?: return emptyList()
        val lastSaved = prefs.getLong("saved_at", 0)

        if (System.currentTimeMillis() - lastSaved > 24 * 60 * 60 * 1000) {
            return emptyList()
        }

        return try {
            val type = object : TypeToken<List<TabState>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clearRecovery() {
        prefs.edit().clear().apply()
    }

    fun markRunning() {
        prefs.edit().putBoolean("is_running", true).apply()
    }

    fun markStopped() {
        prefs.edit().putBoolean("is_running", false).apply()
    }

    fun didPreviousSessionCrash(): Boolean {
        return prefs.getBoolean("is_running", false)
    }
}