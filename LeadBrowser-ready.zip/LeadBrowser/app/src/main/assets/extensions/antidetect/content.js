(function() {
    'use strict';

    const waitForConfig = () => {
        return new Promise((resolve) => {
            const checkConfig = () => {
                if (window.__ANTIDETECT_CONFIG__) {
                    resolve(window.__ANTIDETECT_CONFIG__);
                } else {
                    setTimeout(checkConfig, 1);
                }
            };
            checkConfig();
        });
    };

    waitForConfig().then(config => {
        applyMobileSpoofing(config);
    });

    function applyMobileSpoofing(config) {

        // 1. WEBDRIVER REMOVAL
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        ['cdc_adoQpoasnfa76pfcZLmcfl_Array', 'cdc_adoQpoasnfa76pfcZLmcfl_Promise',
         'cdc_adoQpoasnfa76pfcZLmcfl_Symbol', '_phantom', '__nightmare', '_selenium',
         'callPhantom', '__selenium_unwrapped', '__webdriver_evaluate', '__driver_evaluate',
         'domAutomation', 'domAutomationController'].forEach(prop => {
            try { delete window[prop]; } catch(e) {}
        });

        // 2. CHROME OBJECT
        if (config.hasChromeObject && !window.chrome) {
            window.chrome = {
                runtime: {
                    connect: function() { return { onMessage: { addListener: function() {} } }; },
                    sendMessage: function() {}
                },
                loadTimes: function() {
                    return {
                        commitLoadTime: Date.now() / 1000,
                        connectionInfo: 'h2',
                        finishDocumentLoadTime: Date.now() / 1000,
                        finishLoadTime: Date.now() / 1000,
                        firstPaintAfterLoadTime: 0,
                        firstPaintTime: Date.now() / 1000,
                        navigationType: 'Other',
                        requestTime: Date.now() / 1000,
                        startLoadTime: Date.now() / 1000,
                        wasFetchedViaSpdy: true,
                        wasNpnNegotiated: true
                    };
                },
                csi: function() {
                    return { onloadT: Date.now(), startE: Date.now(), pageT: Math.random() * 1000, tran: 15 };
                }
            };
        }

        // 3. PLUGINS
        Object.defineProperty(navigator, 'plugins', {
            get: () => {
                const plugins = { length: 0 };
                plugins.item = () => null;
                plugins.namedItem = () => null;
                plugins.refresh = () => {};
                return plugins;
            }
        });

        // 4. MIME TYPES
        if (config.mimeTypes && config.mimeTypes.length > 0) {
            const mimeTypesArray = config.mimeTypes.map(m => ({
                type: m.type, suffixes: m.suffixes, description: '', enabledPlugin: null
            }));
            Object.defineProperty(navigator, 'mimeTypes', {
                get: () => {
                    const mimeTypes = {
                        length: mimeTypesArray.length,
                        item: (index) => mimeTypesArray[index] || null,
                        namedItem: (type) => mimeTypesArray.find(m => m.type === type) || null
                    };
                    mimeTypesArray.forEach((mimeType, index) => { mimeTypes[index] = mimeType; });
                    return mimeTypes;
                }
            });
        }

        // 5. NAVIGATOR PROPERTIES
        const navigatorProps = {
            platform: config.platform,
            languages: [config.locale, 'en'],
            language: config.locale,
            hardwareConcurrency: config.hardwareConcurrency,
            deviceMemory: config.deviceMemory,
            maxTouchPoints: config.maxTouchPoints,
            cookieEnabled: true,
            vendor: config.vendor,
            vendorSub: config.vendorSub,
            productSub: config.productSub,
            userAgent: config.userAgent
        };
        Object.keys(navigatorProps).forEach(prop => {
            Object.defineProperty(navigator, prop, { get: () => navigatorProps[prop] });
        });

        // 6. TOUCH SUPPORT
        if (config.touchSupport) {
            Object.defineProperty(navigator, 'maxTouchPoints', { get: () => config.maxTouchPoints });
            if (!('ontouchstart' in window)) {
                window.ontouchstart = function() {};
            }
        }

        // 7. DEVICE PIXEL RATIO
        if (config.devicePixelRatio) {
            Object.defineProperty(window, 'devicePixelRatio', { get: () => config.devicePixelRatio });
        }

        // 8. SCREEN PROPERTIES
        const screenProps = {
            width: config.screenWidth,
            height: config.screenHeight,
            availWidth: config.screenWidth,
            availHeight: config.screenHeight - 80,
            colorDepth: config.screenColorDepth,
            pixelDepth: config.screenColorDepth
        };
        Object.keys(screenProps).forEach(prop => {
            Object.defineProperty(screen, prop, { get: () => screenProps[prop] });
        });

        // 9. CONNECTION API
        if (navigator.connection) {
            Object.defineProperty(navigator.connection, 'effectiveType', { get: () => config.connectionType });
            Object.defineProperty(navigator.connection, 'downlink', { get: () => config.connectionDownlink });
            Object.defineProperty(navigator.connection, 'rtt', { get: () => config.connectionRTT });
            Object.defineProperty(navigator.connection, 'saveData', { get: () => false });
        }

        // 10. CANVAS SPOOFING
        const canvasSeed = config.canvasNoiseSeed || Math.random() * 1000000;
        const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
        const originalToBlob = HTMLCanvasElement.prototype.toBlob;
        const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;

        HTMLCanvasElement.prototype.toDataURL = function(type) {
            if (this.getContext('2d')) {
                const ctx = this.getContext('2d');
                const imageData = originalGetImageData.call(ctx, 0, 0, this.width, this.height);
                for (let i = 0; i < imageData.data.length; i += 4) {
                    const noise1 = Math.sin(canvasSeed + i * 0.01) * 2;
                    const noise2 = (Math.random() - 0.5) * 1;
                    const x = (i / 4) % this.width;
                    const y = Math.floor((i / 4) / this.width);
                    const noise3 = Math.sin(x * 0.1 + canvasSeed) * Math.cos(y * 0.1 + canvasSeed);
                    const totalNoise = noise1 + noise2 + noise3;
                    imageData.data[i] = Math.max(0, Math.min(255, imageData.data[i] + totalNoise));
                }
                ctx.putImageData(imageData, 0, 0);
            }
            return originalToDataURL.apply(this, arguments);
        };

        HTMLCanvasElement.prototype.toBlob = function(callback, type, quality) {
            if (this.getContext('2d')) {
                const ctx = this.getContext('2d');
                const imageData = originalGetImageData.call(ctx, 0, 0, this.width, this.height);
                for (let i = 0; i < imageData.data.length; i += 4) {
                    const noise = Math.sin(canvasSeed + i * 0.01) * 2 + (Math.random() - 0.5);
                    imageData.data[i] = Math.max(0, Math.min(255, imageData.data[i] + noise));
                }
                ctx.putImageData(imageData, 0, 0);
            }
            return originalToBlob.apply(this, arguments);
        };

        // 11. WEBGL SPOOFING
        const getParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(parameter) {
            if (parameter === 37445) return config.webglVendor;
            if (parameter === 37446) return config.webglRenderer;
            return getParameter.apply(this, arguments);
        };
        if (typeof WebGL2RenderingContext !== 'undefined') {
            const getParameter2 = WebGL2RenderingContext.prototype.getParameter;
            WebGL2RenderingContext.prototype.getParameter = function(parameter) {
                if (parameter === 37445) return config.webglVendor;
                if (parameter === 37446) return config.webglRenderer;
                return getParameter2.apply(this, arguments);
            };
        }

        // 12. AUDIO SPOOFING
        const audioSeed = config.audioNoiseSeed || Math.random() * 1000000;
        const originalGetChannelData = AudioBuffer.prototype.getChannelData;
        AudioBuffer.prototype.getChannelData = function(channel) {
            const data = originalGetChannelData.apply(this, arguments);
            for (let i = 0; i < data.length; i++) {
                data[i] = data[i] + Math.sin(audioSeed + i * 0.01) * 1e-10;
            }
            return data;
        };

        // 13. TIMEZONE SPOOFING
        if (config.timezone) {
            const OriginalDate = Date;
            const OriginalDateTimeFormat = Intl.DateTimeFormat;
            window.Date = class extends OriginalDate {
                constructor(...args) {
                    if (args.length === 0) return new OriginalDate();
                    return new OriginalDate(...args);
                }
                static now() { return OriginalDate.now(); }
                getTimezoneOffset() { return config.timezoneOffset || 0; }
                toString() {
                    const str = OriginalDate.prototype.toString.apply(this);
                    const offset = config.timezoneOffset || 0;
                    const sign = offset >= 0 ? '+' : '-';
                    const hours = Math.abs(Math.floor(offset / 60)).toString().padStart(2, '0');
                    const minutes = Math.abs(offset % 60).toString().padStart(2, '0');
                    return str.replace(/GMT[+-]\d{4}/, `GMT${sign}${hours}${minutes}`);
                }
            };
            Object.setPrototypeOf(window.Date, OriginalDate);
            Intl.DateTimeFormat = function(locales, options) {
                const formatter = new OriginalDateTimeFormat(locales, options);
                const originalResolvedOptions = formatter.resolvedOptions.bind(formatter);
                formatter.resolvedOptions = function() {
                    const opts = originalResolvedOptions();
                    opts.timeZone = config.timezone;
                    return opts;
                };
                return formatter;
            };
            Object.setPrototypeOf(Intl.DateTimeFormat, OriginalDateTimeFormat);
        }

        // 14. GEOLOCATION SPOOFING
        if (config.geoLat && config.geoLon && navigator.geolocation) {
            const mockPosition = {
                coords: {
                    latitude: config.geoLat,
                    longitude: config.geoLon,
                    accuracy: 10,
                    altitude: null,
                    altitudeAccuracy: null,
                    heading: null,
                    speed: null
                },
                timestamp: Date.now()
            };
            navigator.geolocation.getCurrentPosition = function(success) { success(mockPosition); };
            navigator.geolocation.watchPosition = function(success) { success(mockPosition); return 1; };
        }

        // 15. FONT FINGERPRINT PROTECTION
        const originalMeasureText = CanvasRenderingContext2D.prototype.measureText;
        CanvasRenderingContext2D.prototype.measureText = function(text) {
            const metrics = originalMeasureText.apply(this, arguments);
            const variation = Math.sin(canvasSeed) * 0.01;
            return {
                width: metrics.width + variation,
                actualBoundingBoxAscent: metrics.actualBoundingBoxAscent,
                actualBoundingBoxDescent: metrics.actualBoundingBoxDescent,
                actualBoundingBoxLeft: metrics.actualBoundingBoxLeft,
                actualBoundingBoxRight: metrics.actualBoundingBoxRight,
                fontBoundingBoxAscent: metrics.fontBoundingBoxAscent,
                fontBoundingBoxDescent: metrics.fontBoundingBoxDescent
            };
        };

        // 16. CLIENT RECTS SPOOFING
        const originalGetBoundingClientRect = Element.prototype.getBoundingClientRect;
        Element.prototype.getBoundingClientRect = function() {
            const rect = originalGetBoundingClientRect.apply(this, arguments);
            const variation = Math.sin(canvasSeed + rect.x + rect.y) * 0.1;
            return {
                x: rect.x + variation, y: rect.y + variation,
                width: rect.width + variation, height: rect.height + variation,
                top: rect.top + variation, right: rect.right + variation,
                bottom: rect.bottom + variation, left: rect.left + variation
            };
        };

        // 17. BATTERY API SPOOFING
        if (navigator.getBattery) {
            const originalGetBattery = navigator.getBattery.bind(navigator);
            navigator.getBattery = function() {
                return originalGetBattery().then(battery => {
                    Object.defineProperty(battery, 'level', { get: () => 0.5 + Math.sin(canvasSeed) * 0.3 });
                    Object.defineProperty(battery, 'charging', { get: () => Math.sin(canvasSeed) > 0 });
                    Object.defineProperty(battery, 'chargingTime', { get: () => Infinity });
                    Object.defineProperty(battery, 'dischargingTime', { get: () => 3600 });
                    return battery;
                });
            };
        }

        // 18. TIMING ATTACK PROTECTION
        const originalPerformanceNow = performance.now.bind(performance);
        const timingOffset = Math.random() * 100;
        performance.now = function() { return originalPerformanceNow() + timingOffset; };

        // 19. DEVICE ORIENTATION
        if (config.isMobile && 'DeviceOrientationEvent' in window) {
            const originalAddEventListener = window.addEventListener;
            window.addEventListener = function(type, listener, options) {
                if (type === 'deviceorientation' || type === 'devicemotion') {
                    const wrappedListener = function(event) {
                        listener({
                            ...event,
                            alpha: Math.random() * 360,
                            beta: Math.random() * 180 - 90,
                            gamma: Math.random() * 90 - 45
                        });
                    };
                    return originalAddEventListener.call(this, type, wrappedListener, options);
                }
                return originalAddEventListener.call(this, type, listener, options);
            };
        }

        // 20. AD VISIBILITY SPOOFING
        const OriginalIntersectionObserver = window.IntersectionObserver;
        window.IntersectionObserver = class extends OriginalIntersectionObserver {
            constructor(callback, options) {
                const wrappedCallback = (entries) => {
                    const modifiedEntries = entries.map(entry => {
                        if (entry.target.classList &&
                            (entry.target.classList.contains('ad-container') ||
                             entry.target.id.includes('ad'))) {
                            return { ...entry, isIntersecting: true, intersectionRatio: 1.0 };
                        }
                        return entry;
                    });
                    callback(modifiedEntries);
                };
                super(wrappedCallback, options);
            }
        };

        Object.defineProperty(document, 'hasFocus', { value: () => true, writable: false });
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible' });
        Object.defineProperty(document, 'hidden', { get: () => false });

        console.log('[Anti-Detect] Android Mobile spoofing active');
    }
})();