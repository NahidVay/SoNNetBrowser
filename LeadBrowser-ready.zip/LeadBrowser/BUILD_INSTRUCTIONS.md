# LeadBrowser — Build Instructions

This project has been fully prepared per the exact specification in `prompt.txt`.
All launcher icons have been generated from your uploaded `icon.png` and placed
in the correct `mipmap-*` folders. `gradle.properties` has been updated with the
required build optimizations. `settings.gradle.kts` already contains the Mozilla
Maven repository.

You just need to run the build on a machine that has the required SDK/NDK.

---

## ✅ Pre-flight checklist (already done)

- [x] Project extracted into `LeadBrowser/`
- [x] Mozilla Maven repository present in `settings.gradle.kts`
- [x] Exact dependencies pinned in `app/build.gradle.kts`
- [x] `gradle.properties` set with `-Xmx4096m`, `parallel`, `caching`
- [x] Launcher icons generated from `icon.png`:
  - `mipmap-mdpi/ic_launcher.png` + `ic_launcher_round.png` (48×48)
  - `mipmap-hdpi/ic_launcher.png` + `ic_launcher_round.png` (72×72)
  - `mipmap-xhdpi/ic_launcher.png` + `ic_launcher_round.png` (96×96)
  - `mipmap-xxhdpi/ic_launcher.png` + `ic_launcher_round.png` (144×144)
  - `mipmap-xxxhdpi/ic_launcher.png` + `ic_launcher_round.png` (192×192)
- [x] Adaptive-icon foreground PNGs also generated for API 26+ devices
- [x] Round icons use circular mask on `#1A0B2E` dark-purple background

---

## 🛠️ Required environment (DO NOT change any version)

| Component            | Version                                  |
|----------------------|------------------------------------------|
| JDK                  | 17 (OpenJDK 17)                          |
| Gradle               | 8.2                                      |
| Android Gradle Plugin| 8.2.0                                    |
| Kotlin               | 1.9.22                                   |
| Compose Compiler     | 1.5.8                                    |
| KSP                  | 1.9.22-1.0.16                            |
| Compile SDK          | 35                                       |
| Target SDK           | 35                                       |
| Min SDK              | 26 (Android 8.0)                         |
| Build Tools          | 35.0.0                                   |
| NDK                  | 26.1.10909125                            |
| GeckoView            | org.mozilla.geckoview:geckoview-omni:128.0.20240613173042 |

---

## 🔨 Build steps

### 1. Install JDK 17

**Ubuntu / Debian:**
```bash
sudo apt-get update && sudo apt-get install -y openjdk-17-jdk
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
```

**macOS (Homebrew):**
```bash
brew install openjdk@17
export JAVA_HOME=$(/usr/libexec/java_home -v 17)
```

**Windows:** Install Adoptium Temurin 17, set `JAVA_HOME`.

### 2. Install Android SDK components

```bash
sdkmanager "platforms;android-35" "build-tools;35.0.0" "platform-tools" "ndk;26.1.10909125"
```

### 3. Create `local.properties` in project root

```properties
sdk.dir=/path/to/Android/Sdk
ndk.dir=/path/to/Android/Sdk/ndk/26.1.10909125
```

Adjust paths for your OS. Example paths:
- Linux: `/home/<user>/Android/Sdk`
- macOS: `/Users/<user>/Library/Android/sdk`
- Windows: `C:\\Users\\<user>\\AppData\\Local\\Android\\Sdk`

### 4. Build the APK

```bash
# Linux / macOS
chmod +x gradlew
./gradlew clean
./gradlew assembleDebug

# Windows
gradlew.bat clean
gradlew.bat assembleDebug
```

First build takes **15–30 minutes** because GeckoView native libraries
(~150 MB) must be downloaded from `https://maven.mozilla.org/maven2/`.

### 5. Output

```
app/build/outputs/apk/debug/app-debug.apk
```

Expected size: **100–200 MB** (GeckoView-based browser).

---

## 🚀 Alternative: Open in Android Studio

1. Open Android Studio (Hedgehog 2023.1.1 or newer)
2. **File → Open** → select the `LeadBrowser` folder
3. Let Gradle Sync finish (5–10 minutes first time)
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**

---

## 🌐 Alternative: Build via GitHub Actions (recommended if no local Android SDK)

Push this folder to a GitHub repo and add `.github/workflows/build.yml`:

```yaml
name: Build LeadBrowser APK
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - name: Install SDK components
        run: |
          sdkmanager "platforms;android-35" "build-tools;35.0.0" \
                     "platform-tools" "ndk;26.1.10909125"
      - name: Build debug APK
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: LeadBrowser-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

GitHub gives you a free download link to the built APK.

---

## 🔍 If Gradle Sync fails

Per the spec, **do not** change versions. Instead check:

1. Internet access to `https://maven.mozilla.org/maven2/`
2. `JAVA_HOME` points at JDK 17
3. `local.properties` `sdk.dir` and `ndk.dir` are correct
4. Android SDK 35 + Build Tools 35.0.0 + NDK 26.1.10909125 all installed
5. In Android Studio: **File → Invalidate Caches → Restart**

---

Icons and configuration are ready. Just run `./gradlew assembleDebug` on a
machine with the environment above and you'll get `app-debug.apk`.
